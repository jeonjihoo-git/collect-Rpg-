# 루미나 크로니클 — P0 베기 명중 이펙트 시범 v1

제작일: 2026-11-05. 상태: **디자인 승인 대기 / Unity 임포트 검수 대기**.

## 요청서 분석과 작업 범위

근거: `GPT_ASSET_REQUESTS.md` 전체, 2026-11-04, Claude 기준 코드 `ccr-1db5d66b-y2xd19 @ f8c7835`.
이번 판단은 요청서의 구현 조사 결과를 기준으로 한다. 현재 저장소를 다시 분석하거나 Unity를 실행한 결과가 아니다.

| 구분 | 처리 |
| --- | --- |
| P0 A1 타격 VFX 17장 | 대표 1종 `Impact_Blade_4x4.png`만 시범 제작 |
| P0 A2 아이콘 29장 | 다음 단계, 이번 묶음에 없음 |
| P0 A3 기본 무기 16종 | FBX 제작 환경 확인, 이번 묶음에 없음 |
| 기존 공격 모션·VFX 타이밍·HUD 기능·음향 슬롯 | 요청서에서 완성된 기능으로 분류. 재제작하지 않음 |
| P1·P2 및 정식 캐릭터·전용무기·유물 등 보류 항목 | 미착수. 기존 설정을 새로 정의하지 않음 |

원본 일러스트를 생성한 후 픽셀 규격만 정규화했다. PNG, 문서, 검수용 미리보기만 제공하며 Unity 코드, 프리팹, `.meta`는 포함하지 않는다. 기존 웹 프로젝트도 수정하지 않았다.

## 디자인

얇은 대각선 십자 섬광에 각진 금속 불꽃을 더했다. 첫 프레임에서 바로 최대 밝기로 명중하고, 십자 선과 파편이 순서대로 소멸한다. 색상을 굽지 않아 기존 코드의 무기·원소 색을 적용할 수 있다. 바람·불 색상 미리보기는 요청서의 `#7FF0C8`, `#FF6A3D`를 사용했다. 별도 색상 텍스처를 추가한 것이 아니다.

## 최종 파일

- 경로: `assets/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png`
- 1024×1024, PNG RGBA8(32bit), 흰색·회색조 + 실제 알파.
- 4×4 = 16프레임. 셀 256×256. 좌상단 0번부터 행 우선으로 우하단 15번까지.
- 각 셀의 바깥 4px 알파값 0 확인. 셀 중심 피벗 `(0.5, 0.5)` 사용.
- 263,450 bytes. SHA-256은 `assets/LuminaArt/Vfx/MANIFEST.md`와 검사 JSON에 기록.

## Unity 담당 적용 안내

1. 디자인 승인 후 최종 PNG만 `Assets/Lumina/Resources/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png`로 옮긴다. `source`와 `review`는 임포트하지 않는다.
2. 최초 확인용 권장값: Texture Type `Default`, sRGB 켬, Alpha Source `Input Texture Alpha`, Wrap `Clamp`, Filter `Bilinear`, Max Size `1024`, Mip Maps 끔, Compression `None`. 이는 검수용 시작값이며 최종 플랫폼 설정은 Unity 담당이 결정한다.
3. 프로젝트의 기존 투명 VFX 재질에 연결한다. 권장 검수는 **알파를 곱하는 Additive 블렌딩**이다. 투명 픽셀의 RGB가 검정인 straight-alpha 파일이므로, 알파를 무시하는 Opaque 재질은 사용하지 않는다. 특정 렌더 파이프라인이나 셰이더가 존재한다고 가정하지 않는다.
4. 표준 Particle System으로 별도 미리보기할 경우 Texture Sheet Animation을 `Grid`, Tiles `4 × 4`, Animation `Whole Sheet`, Start Frame `0`, Cycles `1`로 설정한다. 프레임 진행은 수명에 따라 0→1로 한다. 기존 `VfxSystem` 연결에서는 프로젝트의 프레임 선택 방식을 그대로 따른다.
5. UV를 직접 지정한다면 0부터 시작하는 프레임 `i`에 대해 `column = i % 4`, `row = floor(i / 4)`이다. 일반적인 좌하단 원점 UV에서 scale=`(0.25, 0.25)`, offset=`(column / 4, (3 - row) / 4)`. 0번의 큰 섬광과 15번의 거의 소멸된 상태로 순서 및 상하 반전을 확인한다.
6. Sprite 방식이면 Sprite Mode `Multiple`, Grid by Cell Size `256×256`, 중심 피벗으로 자른다. 자동 이름 순서에 의존하지 말고 실제 화면상 0→15 순서를 확인한다.
7. 타격 발생 시점·위치·크기·재생시간은 기존 코드 값을 유지한다. 동봉된 GIF는 비교용으로 20ms/프레임(유효 16프레임 320ms), 느린 GIF는 80ms/프레임을 사용한다. GIF 끝에 넣은 반복 대기 시간은 게임 사양이 아니다.
8. 모바일 빌드는 요청서대로 ASTC를 적용하되, 무압축본과 64px 표시를 비교한다. 가는 선과 낮은 알파의 손실, 셀 경계 번짐, 밝은 전장에서도 읽히는지 확인한다. 본 묶음에서 ASTC나 기기 검증을 수행하지는 않았다.

Grid / Whole Sheet / Start Frame / Cycles 정의 참고: [Unity 6 Texture Sheet Animation](https://docs.unity3d.com/6000.0/Documentation/Manual/PartSysTexSheetAnimModule.html).

## 검수 자료와 제한

- `review/Vfx/BladeImpactPilotV1/FirstFramePreview.png`: 128px와 실제 64px 표시, 바람·불 틴트.
- `FrameContactSheet.png`: 전체 16프레임을 배경 위에 합성한 검수 시트.
- `Playback.gif`, `PlaybackSlow.gif`: 일반·느린 오프라인 재생. Unity 캡처가 아니다.
- `Validation.json`: 규격, 셀별 알파 경계, 밝기, SHA-256.
- 확인 완료: PNG RGBA8, 정확한 크기, 모든 가시 RGB 무채색, 셀별 4px 투명 경계, 0번 최대 밝기, 파일 20MB 미만.
- 미확인: 실제 Unity 임포트, 프로젝트 재질과의 블렌딩, 전투 화면 적정 크기, 모바일 ASTC 품질 및 GPU 비용.
- 알려진 미세 사항: 12번 프레임의 아주 약한 잔광 총량이 11번보다 소폭 높다(0번 밝기의 약 0.027%). 15번은 RGB 밝기 0이며 일부 중앙 픽셀에 최대 4/255 알파가 남아 있다. 알파를 곱하는 Additive에서는 발광 기여가 없지만 Alpha Blend에서는 끝 프레임의 미세한 어두워짐을 확인해야 한다. 따라서 **15번 전체 알파가 0인 파일로 표기하지 않는다**.
- 생성 이미지 특성상 파편 위치가 수학적 궤적으로 보장되지는 않는다. 느린 재생에서 중심의 흔들림·파편의 연결감도 디자인 승인 시 함께 검토한다.

## FBX 제작 가능 여부

현재 세션에서는 Blender 실행 파일, Python `bpy`, FBX 내보내기 도구 및 연결된 3D 생성 도구를 확인하지 못했다. 따라서 지금 **규격 검증을 마친 바이너리 FBX를 납품할 수 있다고 약속할 수 없다**. 이번 결과에 3D 모델은 없다. PNG나 GLB를 FBX로 이름만 바꾸어 전달하지 않는다.

가능한 범위는 기본 무기의 2048×1024 정면·측면 레퍼런스 제작이다(요청서 A3의 허용 대안). 이것은 모델이 아니며, 제작에는 별도 승인이 필요하다. 실제 FBX 작업은 Blender/FBX 내보내기가 가능한 환경을 확보한 뒤 단위 m, +Y 위/+Z 전방, 회전·스케일 적용, 손잡이 원점, 부품 피벗 및 `Tip`·`Trail_Base` 등 지정 Empty, 삼각형 수와 재질 수를 검사해야 한다.

## 전달 및 다음 단계

Windows Codex에서 ZIP을 풀어 `gpt-handoff/` 내용만 `gpt-work/unity-assets` 브랜치에 검토 후 반영한다. 이번 작업에서 GitHub 업로드·커밋은 하지 않았다.

커밋 제안: `asset(vfx): add blade impact flipbook pilot v1`

먼저 이 1종의 십자 섬광 실루엣·금속 불꽃·소멸 흐름을 승인받는다. 승인 전 다른 A1 텍스처의 양산을 시작하지 않는다. 승인 후 요청서 순서대로 A1 나머지 16종, A2를 이어간다.
