# VFX Pilot Manifest — BladeImpactPilotV1

Status: Design approval pending; Unity import/runtime verification pending.

| File | Size | Format | Frames | Bytes |
| --- | --- | --- | --- | --- |
| `Impact/Impact_Blade_4x4.png` | 1024×1024 | PNG RGBA8, neutral grayscale, straight alpha | 4×4, 16; 256×256 each | 263450 |

- SHA-256: `a04d790fc43358d07b8d842998713fbb975b783fe7d2d388d8fefe4a9c1f54d5`
- Order: top-left to bottom-right, row-major. Pivot: cell center.
- Padding: first/last 4 pixels of every cell have alpha=0 (validated).
- Triangles / 9-slice: N/A (VFX texture, not model or UI border).
- Generation: OpenAI ImageGen; initial generation followed by a padding/alignment revision.
- Export normalization: neutral grayscale conversion, alpha speckle cleanup at <=2/255, 1254×1254 to exact 1024×1024 Lanczos resize. No Unity code modification.
- Original accepted generated image and exact prompts: `../../../source/Vfx/BladeImpactPilotV1/` (relative to this document).
- License/provenance: project-directed generated image; no external stock image or reference-game asset used. No third-party CC0 or paid-asset license is asserted. Use of the generated output is subject to the applicable OpenAI service terms; this manifest makes no exclusive-copyright guarantee.
- Inspection outputs: `../../../review/Vfx/BladeImpactPilotV1/`.
- Known limitations: no Unity/device/ASTC run; low-energy tail is not strictly monotonic (frame 12); final frame has RGB=0 with residual alpha up to 4/255. Prefer alpha-weighted additive blending. See README for inspection guidance.
- Source basis: Claude request v1, 2026-11-04, `ccr-1db5d66b-y2xd19 @ f8c7835`. Live source was not re-audited in this asset-only task.
- Handoff destination: `Assets/Lumina/Resources/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png` (to be imported by Unity lead after approval).

All other files in this package are documentation, source provenance or offline review materials, not additional production textures.
