"""Technical export + inspection only; artwork was generated with ImageGen.
Run with Python 3, Pillow and numpy. Does not modify any Unity project.
"""
from pathlib import Path
import hashlib, json, shutil, struct
import numpy as np
from PIL import Image, ImageDraw, ImageFont

HERE = Path(__file__).resolve().parent
ROOT = HERE.parents[2]
OUT = ROOT / 'assets/LuminaArt/Vfx/Impact'
REVIEW = ROOT / 'review/Vfx/BladeImpactPilotV1'
OUT.mkdir(parents=True, exist_ok=True)
REVIEW.mkdir(parents=True, exist_ok=True)
raw = Image.open(HERE / 'GeneratedSource.png').convert('RGBA')
# Required delivery format: neutral monochrome, straight alpha, exact 1024 square.
# Remove nearly invisible alpha 1/2 quantization speckles before and after resize.
arr = np.array(raw)
arr[:, :, 3][arr[:, :, 3] <= 2] = 0
grey = np.array(Image.fromarray(arr[:, :, :3]).convert('L'))
arr[:, :, :3] = grey[:, :, None]
arr[arr[:, :, 3] == 0] = 0
im = Image.fromarray(arr).resize((1024, 1024), Image.Resampling.LANCZOS)
arr = np.array(im)
arr[:, :, 3][arr[:, :, 3] <= 2] = 0
arr[arr[:, :, 3] == 0] = 0
im = Image.fromarray(arr, 'RGBA')
target = OUT / 'Impact_Blade_4x4.png'
im.save(target, optimize=True)

frames, stats = [], []
for i in range(16):
    r, c = divmod(i, 4)
    f = im.crop((c*256, r*256, (c+1)*256, (r+1)*256))
    frames.append(f)
    t = np.array(f); a = t[:, :, 3]
    edges = np.concatenate((a[:4].ravel(), a[-4:].ravel(), a[:, :4].ravel(), a[:, -4:].ravel()))
    energy = float((a.astype(float)/255*t[:, :, 0]).sum())
    stats.append({'frame': i, 'alpha_bbox': a_bbox if (a_bbox := f.getchannel('A').getbbox()) else None,
                  'edge_4px_alpha_max': int(edges.max()), 'alpha_max': int(a.max()),
                  'luminance_times_alpha_sum': round(energy, 3)})

qa = {'asset': target.relative_to(ROOT).as_posix(), 'size': list(im.size), 'mode': im.mode,
      'png_bit_depth': target.read_bytes()[24], 'png_color_type': target.read_bytes()[25],
      'sha256': hashlib.sha256(target.read_bytes()).hexdigest(), 'bytes': target.stat().st_size,
      'grid': [4,4], 'cell_px': [256,256], 'order': 'top-left, row-major',
      'source_size': list(raw.size), 'normalization': ['RGB to neutral grayscale', 'alpha <= 2/255 to zero', 'Lanczos resize to 1024 square'],
      'tests': {'rgba8': im.mode == 'RGBA' and target.read_bytes()[24] == 8,
                'exact_size': im.size == (1024,1024),
                'neutral_grayscale': bool(np.all(arr[:,:,0] == arr[:,:,1]) and np.all(arr[:,:,1] == arr[:,:,2])),
                'all_cells_4px_clear': all(s['edge_4px_alpha_max'] == 0 for s in stats),
                'brightest_frame_is_0': stats[0]['luminance_times_alpha_sum'] == max(s['luminance_times_alpha_sum'] for s in stats),
                'under_20MB': target.stat().st_size < 20000000},
      'frames': stats, 'unity_editor_run': False, 'device_run': False,
      'notes': ['Preview is offline alpha compositing, not Unity render.', 'No gameplay timing or code changed.']}
assert all(qa['tests'].values()), qa['tests']
(REVIEW/'Validation.json').write_text(json.dumps(qa, indent=2), encoding='utf-8')

font=ImageFont.load_default(size=16)
small=ImageFont.load_default(size=12)
bg=(18,26,44)
contact=Image.new('RGB',(800,912),bg)
d=ImageDraw.Draw(contact)
d.text((16,12),'LUMINA / BLADE IMPACT / FRAME INSPECTION',font=font,fill='white')
d.text((16,38),'16 frames - row-major - alpha composite on #121A2C - 192px previews',font=small,fill=(160,170,190))
for i,f in enumerate(frames):
    r,c=divmod(i,4); x=8+c*198; y=70+r*208
    contact.paste(f.resize((192,192),Image.Resampling.LANCZOS),(x,y),f.resize((192,192),Image.Resampling.LANCZOS))
    d.text((x+8,y+185),f'{i:02}',font=small,fill=(160,170,190))
contact.save(REVIEW/'FrameContactSheet.png')

def tinted(f, color):
    t=np.array(f).copy()
    t[:,:,:3]=(t[:,:,:3].astype(float)*np.array(color)/255).astype(np.uint8)
    return Image.fromarray(t)

previews=[]
colors=[(255,255,255),(255,255,255),(127,240,200),(255,106,61)]
labels=['White / 128px','Mobile / 64px','Wind / 128px','Fire / 128px']
for f in frames:
    canvas=Image.new('RGB',(608,204),bg); d=ImageDraw.Draw(canvas)
    d.text((16,10),'BLADE IMPACT - OFFLINE PREVIEW',font=font,fill='white')
    for n,(color,label) in enumerate(zip(colors,labels)):
        size=64 if n==1 else 128
        q=tinted(f,color).resize((size,size),Image.Resampling.LANCZOS)
        x=16+n*148+(128-size)//2; y=42+(128-size)//2
        canvas.paste(q,(x,y),q)
        d.text((16+n*148,174),label,font=small,fill=(190,200,215))
    previews.append(canvas)
previews[0].save(REVIEW/'FirstFramePreview.png')
previews[0].save(REVIEW/'Playback.gif', save_all=True, append_images=previews[1:],duration=[20]*15+[680],loop=0,disposal=2,optimize=False)
previews[0].save(REVIEW/'PlaybackSlow.gif', save_all=True, append_images=previews[1:],duration=[80]*15+[680],loop=0,disposal=2,optimize=False)
print(json.dumps({'tests':qa['tests'],'sha256':qa['sha256'],'bytes':qa['bytes'],'last_frame':stats[-1]},indent=2))
