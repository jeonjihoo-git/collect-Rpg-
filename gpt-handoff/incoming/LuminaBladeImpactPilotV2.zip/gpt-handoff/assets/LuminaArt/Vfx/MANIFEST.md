# Blade Impact Pilot V2 — MANIFEST

Date: 2026-11-06. Status: Claude re-review / user approval pending.

| Production file | Dimensions | Encoding | Size |
| --- | --- | --- | --- |
| `Impact/Impact_Blade_4x4.png` | 1024×1024, 4×4 cells of 256×256 | PNG RGBA8, straight alpha, monochrome | 163877 bytes |

- SHA-256: `a03cce9d9b24947ecfb7e5798aa84eb785894ddc442fb1d87f655f595b21ae77`.
- Blend classification: **Additive with RGB × Alpha**. Visible RGB is white; intensity resides in alpha. Transparent RGB is black.
- Order: top-left to bottom-right, row-major; 60fps, 16/60 seconds; frame 15 entirely zero.
- Frame 0 visible bounds: 207×206px at alpha >8/255. Largest frame: 225×219px. All cell edges have 8px zero-alpha gutters.
- Pivot/origin: center `(127.5,127.5)` in zero-based pixel indices, equivalent to normalized pivot `(0.5,0.5)`.
- Geometry / 9-slice: not applicable; this is a VFX texture, not a 3D mesh or UI frame.
- Provenance: existing OpenAI ImageGen v1 frame 0, extracted and deterministically composited using Python/Pillow/numpy/scipy as requested in Claude F3. V1 generation prompts are retained. No new model/provider generation call for v2.
- Animation: fixed eight shard identities; outward decelerating radial motion; monotonic particle opacity; anchored slash for frames 0–7, shards only for 8–14.
- License/source: project-generated source image and project-specific authored processing code; no external stock/reference-game texture or third-party CC0 license asserted. No new exclusive-rights guarantee. Applicable generated-output service terms remain those of the original generation.
- Validation: supplied checker, unmodified, **14 PASS / 0 FAIL**, exit 0. Additional layer/motion checks pass. See `../../../review/Vfx/BladeImpactPilotV2/Validation.json` and `DeliveryChecks.json`.
- Limitations: no Unity Editor, live gameplay, device, HDR/linear blending or v2 ASTC run. Offline previews are illustrative additive composites, not Unity captures. Motion continuity checks inspect production parameters/layers, not independent Unity optical tracking.
- Source: `../../../source/Vfx/BladeImpactPilotV2/`. Review: `../../../review/Vfx/BladeImpactPilotV2/`.
- Intended Unity destination: `Assets/Lumina/Resources/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png`, to be integrated by Claude after approval.

This package contains exactly one production asset. Source component PNGs and review images are not additional game assets. The complete package file list and hashes are in `gpt-handoff/SHA256SUMS.txt`.
