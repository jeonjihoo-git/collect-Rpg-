"""Lumina VFX 플립북 납품 자동 검사 (Impact 4x4 시트용).

사용법:  python check_impact_flipbook.py <Impact_xxx_4x4.png>
필요:    Python 3.9+, Pillow, numpy
판정 기준은 'GPT Work 수정 요청서 — 베기 명중 v2'와 같습니다. 모든 항목 PASS 여야 납품 가능.
"""
import sys
import numpy as np
from PIL import Image

CELL, GRID, PAD = 256, 4, 8
# 프레임 0 대비 남은 밝기(%) 허용 구간 — 60fps 1프레임/화면 재생(총 0.27초) 기준
ENERGY_RANGES = {2: (45, 70), 4: (20, 40), 6: (10, 22), 8: (4, 10), 10: (1.5, 5), 12: (0.3, 2.0)}


def main(path):
    im = Image.open(path)
    results = []
    def check(name, ok, detail):
        results.append((name, bool(ok), detail))

    check('형식 RGBA 1024x1024', im.mode == 'RGBA' and im.size == (CELL * GRID, CELL * GRID), f'{im.mode} {im.size}')
    a = np.asarray(im.convert('RGBA')).astype(np.float64) / 255.0
    check('무채색(R=G=B)', np.all((a[..., 0] == a[..., 1]) & (a[..., 1] == a[..., 2])), '색은 코드가 입힘')

    cells, energy = [], []
    for i in range(GRID * GRID):
        r, c = divmod(i, GRID)
        f = a[r * CELL:(r + 1) * CELL, c * CELL:(c + 1) * CELL]
        cells.append(f)
        energy.append(float((f[..., 0] * f[..., 3]).sum()))
    e0 = energy[0] if energy[0] > 0 else 1.0
    pct = [e / e0 * 100 for e in energy]

    border = max(max(f[:PAD, :, 3].max(), f[-PAD:, :, 3].max(), f[:, :PAD, 3].max(), f[:, -PAD:, 3].max()) for f in cells)
    check(f'셀 가장자리 {PAD}px 알파 0', border == 0, f'최대 {border * 255:.0f}/255')

    ys, xs = np.nonzero(cells[0][..., 3] > 8 / 255)
    w = (xs.max() - xs.min() + 1) if len(xs) else 0
    h = (ys.max() - ys.min() + 1) if len(ys) else 0
    check('프레임 0 크기(셀의 70% 이상 = 180px+)', min(w, h) >= 180, f'{w}x{h}px')

    offs = []
    for i in range(3):
        e = cells[i][..., 0] * cells[i][..., 3]
        m = e >= e.max() * 0.9
        yy, xx = np.nonzero(m)
        offs.append(max(abs(xx.mean() - 127.5), abs(yy.mean() - 127.5)))
    check('명중 중심 정렬(프레임 0~2, ±3px)', max(offs) <= 3.0, ' '.join(f'{o:.1f}' for o in offs) + 'px')

    check('프레임 0이 가장 밝음', int(np.argmax(energy)) == 0, '')
    mono = all(pct[i + 1] <= pct[i] + 0.5 for i in range(15))
    check('밝기 단조 감소(허용 0.5%p)', mono, ' '.join(f'{p:.1f}' for p in pct))
    for k, (lo, hi) in ENERGY_RANGES.items():
        check(f'프레임 {k} 남은 밝기 {lo}~{hi}%', lo <= pct[k] <= hi, f'{pct[k]:.2f}%')
    check('프레임 15 완전 투명(알파 전부 0)', cells[15][..., 3].max() == 0, f'최대 {cells[15][..., 3].max() * 255:.0f}/255')

    ok = all(r[1] for r in results)
    for name, passed, detail in results:
        print(f"{'PASS' if passed else 'FAIL'}  {name}  {detail}")
    print('\n결과:', '납품 가능' if ok else '수정 필요')
    return 0 if ok else 1


if __name__ == '__main__':
    sys.exit(main(sys.argv[1]))
