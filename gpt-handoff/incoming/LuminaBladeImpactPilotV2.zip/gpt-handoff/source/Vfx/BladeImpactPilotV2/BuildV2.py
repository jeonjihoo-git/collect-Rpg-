"""Rebuild approved V1 artwork as deterministic V2. No Unity project access.
Python 3.10+; Pillow, numpy, scipy; ffmpeg/ffprobe for video.
User/Claude F3 explicitly requests component extraction and mathematical animation.
"""
from pathlib import Path
import hashlib, json, math, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw, ImageFont
from scipy.ndimage import map_coordinates, distance_transform_edt

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OUT=ROOT/'assets/LuminaArt/Vfx/Impact'
REVIEW=ROOT/'review/Vfx/BladeImpactPilotV2'
OUT.mkdir(parents=True,exist_ok=True); REVIEW.mkdir(parents=True,exist_ok=True)
C=127.5
Y,X=np.mgrid[:256,:256].astype(float)
src=Image.open(HERE/'ApprovedV1.png').convert('RGBA').crop((0,0,256,256))
src.save(HERE/'SourceFrame0.png')
a=np.array(src,dtype=float)/255
emission=a[:,:,0]*a[:,:,3]
# Split the same eight major shards from approved frame zero, in source coordinates.
# Small subsidiary slivers attached to slash arms remain part of the core layer.
POLYGONS=[
 [(102,66),(125,80),(135,115),(120,110),(105,91)],
 [(160,70),(171,72),(165,94),(146,114),(147,96)],
 [(161,125),(178,121),(207,124),(194,142),(163,143)],
 [(160,143),(183,144),(203,164),(177,162),(159,151)],
 [(140,156),(163,166),(169,205),(145,190),(137,168)],
 [(123,156),(127,177),(106,196),(105,176)],
 [(111,138),(98,163),(62,168),(79,147),(99,138)],
 [(115,117),(98,108),(73,107),(80,128),(102,137),(117,136)],
]
used=np.zeros((256,256),bool); parts=[]
for idx,poly in enumerate(POLYGONS):
    m=Image.new('L',(256,256)); ImageDraw.Draw(m).polygon(poly,fill=255)
    mask=(np.array(m)>0)&~used&(((X-135)**2+(Y-133)**2)>32**2);used|=mask
    feather=np.minimum(distance_transform_edt(mask)/1.5,1)
    p=emission*feather
    center=np.array([(p*X).sum()/p.sum(),(p*Y).sum()/p.sum()])
    parts.append((p,center))
bright=emission>=emission.max()*.9
cy,cx=np.nonzero(bright)
origin=np.array([cx.mean(),cy.mean()])
dx=X-origin[0];dy=Y-origin[1];radius=np.hypot(dx,dy)
distance=np.minimum(abs(dx-dy),abs(dx+dy))/np.sqrt(2)
width=17*np.maximum(0,1-radius/100)**1.2
cross_mask=np.clip((width+1.2-distance)/2.4,0,1)
diamond_mask=np.clip((26-abs(dx)-abs(dy))/3,0,1)
core=emission*np.maximum(cross_mask,diamond_mask)

def sample(layer, source_center, target_center, scale):
    coords=[(Y-target_center[1])/scale+source_center[1],(X-target_center[0])/scale+source_center[0]]
    return np.clip(map_coordinates(layer,coords,order=3,mode='constant',cval=0,prefilter=True),0,1)

def png_from_energy(e):
    # Straight-alpha encoding: white RGB and energy in alpha, additive RGB*alpha.
    alpha=np.clip(np.rint(e*255),0,255).astype(np.uint8)
    out=np.zeros((256,256,4),np.uint8)
    out[:,:,:3]=np.where(alpha[:,:,None]>0,255,0)
    out[:,:,3]=alpha
    return Image.fromarray(out,'RGBA')

scale0=1.58
base_core=sample(core,origin,[C,C],scale0)
# Fixed 180-degree pairing removes asymmetric core drift without inventing new artwork.
base_core=(base_core+base_core[::-1,::-1])/2
png_from_energy(base_core).save(HERE/'Core.png')
for j,(p,pc) in enumerate(parts):
    png_from_energy(p).save(HERE/f'Shard{j:02}.png')

TARGET=np.array([100,78,58,43,31,23,16,11,7,4.7,3.0,1.8,.9,.38,.10,0.0])
# Core remains anchored, narrows gently and is completely absent from frame 8 onward.
CORE_PEAK=[.80,.72,.65,.58,.50,.40,.28,.12]
motion=[]; rawframes=[]; layers=[]; core_errors=[]
for i in range(16):
    t=i/14
    if i<8:
        # Narrow the beams smoothly; symmetric geometric scaling preserves intersection.
        cp=base_core.copy()
    else: cp=np.zeros((256,256))
    stack=[cp]
    if cp.max()>0:
        yy,xx=np.nonzero(cp>=cp.max()*.9)
        core_errors.append({'frame':i,'x':float(xx.mean()),'y':float(yy.mean()),'linf_error':float(max(abs(xx.mean()-C),abs(yy.mean()-C)))})
    else: core_errors.append({'frame':i,'x':None,'y':None,'linf_error':None,'reason':'slash absent; origin remains fixed'})
    frame_particles=[]
    for j,(p,pc) in enumerate(parts):
        v=(pc-origin)*scale0
        radius0=np.linalg.norm(v);direction=v/radius0
        # Radius approaches +24px with strictly decreasing positive per-frame steps.
        progress=(1-math.exp(-i/6))/(1-math.exp(-14/6))
        distance=24*progress
        position=np.array([C,C])+direction*(radius0+distance)
        # Continuous, monotonic size; same texture and angle throughout.
        shrink=max(.12,1-.86*(min(i,14)/14)**1.6)
        sp=sample(p,pc,position,scale0*shrink) if i<15 else np.zeros((256,256))
        stack.append(sp)
        frame_particles.append({'id':j,'frame':i,'center':position.tolist(),'radius':float(radius0+distance),'angle_deg':float(np.degrees(math.atan2(direction[1],direction[0]))),'scale':float(scale0*shrink),'born_frame':0})
    motion.append(frame_particles);layers.append(stack)
    rawframes.append(np.clip(sum(stack),0,1))

# Allocate energy separately to core and shards. Particle opacity never rises as
# the slash disappears; this avoids brightness pumping hidden by total-energy tests.
particle_raw=[sum(stack[1:]) for stack in layers]
part_energy=[p.sum() for p in particle_raw]
p0_fraction=.07*math.exp(.48)*part_energy[0]/part_energy[8]
e0=base_core.sum()*.80/(1-p0_fraction)
p8=e0*.07/part_energy[8]
frames=[]; gains=[]; clipping=[]
core_errors=[];core_gain_actual=[];core_scales=[]
for i,raw in enumerate(rawframes):
    target=e0*TARGET[i]/100
    if i==15:
        e=np.zeros((256,256));gain=0;cp=np.zeros((256,256));cg=0;size=0
    else:
        gain=p8*math.exp((8-i)*.06) if i<8 else target/part_energy[i]
        pp=particle_raw[i]*gain
        needed=max(0,target-pp.sum())
        if i<8:
            size=math.sqrt(needed/(base_core.sum()*CORE_PEAK[i]))
            cp=sample(base_core,[C,C],[C,C],size)
            cg=needed/cp.sum()
            cp*=cg
        else:cp=np.zeros((256,256));cg=0;size=0
        e=cp+pp
    core_gain_actual.append(float(cg));core_scales.append(float(size))
    if cp.max()>0:
        yy,xx=np.nonzero(cp>=cp.max()*.9)
        core_errors.append({'frame':i,'x':float(xx.mean()),'y':float(yy.mean()),'linf_error':float(max(abs(xx.mean()-C),abs(yy.mean()-C)))})
    else:core_errors.append({'frame':i,'x':None,'y':None,'linf_error':None,'reason':'slash absent; origin remains fixed'})
    assert e.max()<=1.001, (i,e.max(),gain)
    # Guard gutter, and record any energy that would otherwise touch it.
    border=np.ones((256,256),bool);border[8:-8,8:-8]=False
    clipping.append(float(e[border].sum()))
    e[border]=0
    frames.append(png_from_energy(e));gains.append(float(gain))

atlas=Image.new('RGBA',(1024,1024))
for i,f in enumerate(frames): atlas.paste(f,((i%4)*256,(i//4)*256))
asset=OUT/'Impact_Blade_4x4.png';atlas.save(asset,optimize=True)
energies=[]; frame_metrics=[]
for i,f in enumerate(frames):
    ar=np.array(f,dtype=float)/255;en=ar[:,:,0]*ar[:,:,3];energy=en.sum();energies.append(float(energy))
    yy,xx=np.nonzero(ar[:,:,3]>8/255)
    mask=en>=en.max()*.9 if en.max()>0 else np.zeros_like(en,dtype=bool)
    my,mx=np.nonzero(mask)
    frame_metrics.append({'frame':i,'time_seconds':i/60,'energy':float(energy),'alpha_max':int(np.array(f)[:,:,3].max()),
      'content_size_alpha_gt_8': [int(xx.max()-xx.min()+1),int(yy.max()-yy.min()+1)] if len(xx) else [0,0],
      'brightest_region_linf_error':float(max(abs(mx.mean()-C),abs(my.mean()-C))) if len(mx) else None,
      'slash_center_error':core_errors[i]['linf_error'],'slash_present':i<8,'origin':[C,C], 'gain':gains[i]})
for row in frame_metrics: row['remaining_brightness_pct']=row['energy']/energies[0]*100

result=subprocess.run([sys.executable,str(REVIEW/'check_impact_flipbook.py'),str(asset)],capture_output=True,text=True)
(REVIEW/'CheckResults.txt').write_text(result.stdout+result.stderr,encoding='utf-8')
print(result.stdout)
# Independent component checks beyond the supplied script's scope.
radial=[]
for j in range(8):
    rr=np.array([motion[i][j]['radius'] for i in range(13)])
    dd=np.diff(rr)
    radial.append({'id':j,'outward_every_frame':bool(np.all(dd>0)), 'decelerates_every_frame':bool(np.all(np.diff(dd)<0)), 'steps_px':dd.tolist()})
qa={'source_v1_sha256':hashlib.sha256((HERE/'ApprovedV1.png').read_bytes()).hexdigest(),
    'asset_sha256':hashlib.sha256(asset.read_bytes()).hexdigest(),'bytes':asset.stat().st_size,
    'source_origin':origin.tolist(),'checker_exit_code':result.returncode,'checker_sha256':hashlib.sha256((REVIEW/'check_impact_flipbook.py').read_bytes()).hexdigest(),
    'frames':frame_metrics,'core_centers':core_errors,'particle_motion':motion,'particle_radial_checks':radial,
    'additional_checks':{'fixed_8_particle_ids':all([p['id'] for p in m]==list(range(8)) for m in motion),
        'core_linf_error_le_2':all(r['linf_error'] is None or r['linf_error']<=2 for r in core_errors),
        'outward_decelerating_motion_0_to_12':all(r['outward_every_frame'] and r['decelerates_every_frame'] for r in radial),
        'particle_opacity_never_increases':bool(np.all(np.diff(gains)<=0)),
        'final_alpha_zero':int(np.array(frames[15])[:,:,3].max())==0,
        'no_visible_border_clip':max(clipping)<.05},
    'border_energy_before_guard':clipping,'frame_targets_pct':TARGET.tolist(),
    'encoding':'straight RGBA, white RGB where alpha>0; additive RGB*alpha',
    'unity_editor_tested':False,'astc_v2_tested':False,'device_tested':False}
(REVIEW/'Validation.json').write_text(json.dumps(qa,indent=2),encoding='utf-8')
(HERE/'Motion.json').write_text(json.dumps({'source_origin':origin.tolist(),'particles':motion,'particle_gains':gains,'core_gains':core_gain_actual,'core_scales':core_scales},indent=2),encoding='utf-8')
print('Additional checks:',qa['additional_checks'])
print('gains:',[round(x,3) for x in gains])

# Offline previews using declared additive equation, no bloom or gameplay code.
font=ImageFont.load_default(size=18);small=ImageFont.load_default(size=13)
def add_to(canvas, f, xy, size=128, tint=(255,255,255)):
    q=f.resize((size,size),Image.Resampling.LANCZOS)
    ar=np.array(q,dtype=float)/255
    x,y=xy;back=np.array(canvas.crop((x,y,x+size,y+size)),dtype=float)/255
    rgb=np.clip(back+ar[:,:,:3]*ar[:,:,3:4]*np.array(tint)/255,0,1)
    canvas.paste(Image.fromarray(np.rint(rgb*255).astype(np.uint8)),xy)

contact=Image.new('RGB',(1088,1260),'#121A2C');d=ImageDraw.Draw(contact)
d.text((20,12),'LUMINA / BLADE IMPACT V2 / ADDITIVE FRAME INSPECTION',font=font,fill='white')
for i,f in enumerate(frames):
    x=16+(i%4)*268;y=54+(i//4)*300
    d.rectangle((x,y,x+255,y+255),fill='#38424F');add_to(contact,f,(x,y),256)
    d.text((x,y+262),f'{i:02} | {frame_metrics[i]["remaining_brightness_pct"]:.2f}% | {i/60:.3f}s',font=small,fill='white')
contact.save(REVIEW/'FrameContactSheet.png')

def video_frame(index,slow=False):
    c=Image.new('RGB',(960,600),'#121A2C');d=ImageDraw.Draw(c)
    d.text((20,14),'LUMINA / BLADE IMPACT V2 - OFFLINE ADDITIVE PREVIEW',font=font,fill='white')
    d.text((20,42),'60 fps / 16 frames = 0.267s | pause between repeats | no bloom',font=small,fill='#A3A7AD')
    for row,bg in enumerate(['#38424F','#A3A7AD']):
        y=92+row*244
        for col,(label,size,tint) in enumerate([('WHITE / 128px',128,(255,255,255)),('MOBILE / 64px',64,(255,255,255)),('WIND / 128px',128,(127,240,200)),('FIRE / 128px',128,(255,106,61))]):
            x=20+col*234
            d.rectangle((x,y,x+215,y+191),fill=bg)
            if index<16:add_to(c,frames[index],(x+(216-size)//2,y+(192-size)//2),size,tint)
            d.text((x,y+198),label,font=small,fill='white')
    d.text((20,576),('4x SLOW - inspect continuity' if slow else 'REAL TIME - one atlas frame per video frame'),font=small,fill='white')
    return c

video_frame(0).save(REVIEW/'FirstFramePreview.png')
for name,slow in [('Playback60fps.mp4',False),('PlaybackSlow60fps.mp4',True)]:
    process=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x600','-r','60','-i','-','-an','-c:v','libx264','-preset','medium','-crf','17','-pix_fmt','yuv420p','-movflags','+faststart',str(REVIEW/name)],stdin=subprocess.PIPE)
    count=4 if slow else 1
    for rep in range(4):
        for i in range(16):
            b=video_frame(i,slow).tobytes()
            for _ in range(count):process.stdin.write(b)
        b=video_frame(16,slow).tobytes()
        for _ in range(44):process.stdin.write(b)
    process.stdin.close();assert process.wait()==0

sys.exit(result.returncode or (0 if all(qa['additional_checks'].values()) else 2))
