# 루미나 크로니클 — 베기 명중 이펙트 v3 검수 패키지

상태: **자동 검사 15/15 PASS · 디자인 재검수 및 최종 승인 대기**.
베기 명중 1종만 포함합니다. 기존 Unity 프로젝트·개발 코드·GitHub 브랜치에는 반영하지 않았습니다.
마지막 확인에서는 v3의 모든 알파와 보이는 픽셀을 보존하고, 완전 투명 픽셀의 RGB만 흰색으로 통일했습니다. ASTC 6×6 인코딩 품질은 exhaustive로 높였습니다. 새 그림이나 동작은 제작하지 않았습니다. 상세 판정은 review/Vfx/BladeImpactPilotV3/FinalCheck/FinalReviewReport.md를 먼저 읽어 주세요. v1/v2는 다시 제작하지 않았습니다. 필요한 요청서·v1.1 검사 스크립트·v2 검수 이미지 3종은 모두 확인했습니다.

## 먼저 열어볼 파일

| 용도 | 패키지 내 경로 |
|---|---|
| Unity 적용 후보 원본 | assets/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png |
| 수정 내역/보존한 설정 | assets/LuminaArt/Vfx/MANIFEST.md |
| 검사 로그 | review/Vfx/BladeImpactPilotV3/CheckResults.txt |
| 프레임별 측정값 | review/Vfx/BladeImpactPilotV3/Validation.json, FrameMetrics.csv |
| Gamma / Linear 합성 | review/Vfx/BladeImpactPilotV3/FirstFrameGamma.png, FirstFrameLinear.png |
| 60fps 영상 | review/Vfx/BladeImpactPilotV3/PlaybackGamma60fps.mp4, PlaybackLinear60fps.mp4 |
| 4배 느린 검수 영상 | review/Vfx/BladeImpactPilotV3/PlaybackLinearSlow60fps.mp4 |
| v2/v3 확대 비교 | review/Vfx/BladeImpactPilotV3/DefectZoomComparison.png, DefectDetailComparison.png |
| 16프레임 전체 | review/Vfx/BladeImpactPilotV3/FrameContactSheetLinear.png |
| 실제 ASTC 압축/복원 | review/Vfx/BladeImpactPilotV3/Astc6x6/ |
| 4배 원화 및 제작 수식 | source/Vfx/BladeImpactPilotV3/ |

## 검증 결과와 한계

- RGBA 1024×1024, 4×4, 16프레임, 셀 256×256. 가시 영역 0번 209×209px(81.6%).
- 모든 셀의 가장자리 8px 알파 0, 15번 전체 알파 0.
- 제공된 v1.1 검사 파일을 변경하지 않고 실행한 결과 15개 PASS. 선명도 지표 38.8(기준 ≥15).
- 검사기의 중심 기준은 0~2번 ±3px입니다. 추가로 참격 레이어 0~7번을 측정해 최대 오차 0.264px로 요청의 ±2px도 확인했습니다. 8번 이후 참격 레이어가 소멸하므로 중심은 해당 없음이며 JSON에는 null로 표시합니다. 파편 전체의 무게중심을 참격 중심으로 간주하지 않습니다.
- 첫 프레임 최대 알파 201/255 유지. 상대 밝기 곡선은 v2와 동일합니다. 그림 면적 변경으로 절대 누적 밝기는 v2와 같지 않습니다.
- 확대 비교에서 기존 파편 판·레이어 틈·중앙의 빈 절단 고리·참격 톱니 이음새는 관찰되지 않았습니다.
- **잔여 검수 사항:** 알파를 제곱근으로 강조한 진단 이미지에는 8비트 양자화에 따른 동심원 계조가 보입니다. 기존의 빈 고리와는 다르지만 시각적 무결함 또는 디자인 승인으로 판정하지 않았습니다. 선명도 수치만으로 미적 품질을 보증하지 않습니다.
- 영상은 960×768 H.264, 60fps입니다. 정상 속도 4초에는 16프레임(0.267초) 재생과 대기를 4회 포함합니다. 느린 영상은 각 프레임 4회 표시, 7.2초입니다. ffprobe와 전체 디코딩은 통과했으며 Unity 실행 녹화가 아닙니다.

## Gamma / Linear 미리보기

흰색 RGB와 알파를 기준으로 아래 식을 적용했습니다. 배경은 #38424F 및 #A3A7AD, 쿼드 크기는 128/176/256px입니다.

- Gamma: `out = bg + tint * alpha`
- Linear: `out = linear_to_srgb(srgb_to_linear(bg) + srgb_to_linear(tint) * alpha)`

SDR 범위로 clamp하며 Bloom/HDR/톤매핑/카메라 기울기는 적용하지 않았습니다. 실제 게임 화면과 완전히 동일하지 않습니다. DefectZoomComparison은 0/2/5/8번에 alpha^0.5를 적용한 2배 최근접 확대입니다. 중앙 방사형 측정은 CentralRadialProfiles.json에 있습니다.

## ASTC 6×6 실측

Arm astcenc 5.7.1 SSE2, sRGB LDR, exhaustive 설정으로 실제 압축한 파일과 복원 PNG를 제공합니다. Unity 임포터 및 실기기 GPU 테스트는 아닙니다.

| 항목 | 측정 |
|---|---|
| 파일 크기 | 467,872 bytes (456.9 KiB, 헤더 포함, mipchain 제외) |
| 알파 PSNR | 52.78 dB |
| 최대 픽셀 알파 오차 | 23/255 (국소 최대값) |
| 프레임 0~11 밝기 유지 | 99.42~99.89% |
| 프레임 12~14 밝기 유지 | 98.01~98.88% |
| 복원본 8px 여백 / 15번 | 알파 0 유지 |

얇은 끝부분에 국소 압축 오차가 있으므로 Unity에서 다시 확인해야 합니다. 밝기는 실제 복원 RGB×alpha의 합으로 비교했습니다. CompressionComparison.png 및 FinalCheck 폴더의 최종 비교는 실제 복원 RGB와 알파를 함께 사용합니다. 기존 DefectZoom/Gamma/Linear 원본 미리보기는 알파가 동일하므로 재사용했습니다. v2의 46dB를 v3 측정값으로 재사용하지 않았습니다.

## Unity 적용 안내 — 승인 후 Claude Code 담당

1. 제작용 파일은 assets 아래 PNG **1개**입니다. Reference의 v2 PNG, 비교 PNG, ASTC 복원 PNG를 런타임 에셋으로 넣지 않습니다.
2. 기존 로더·셰이더 계약을 유지하고 4×4 UV 애니메이션에 연결합니다. 원본 순서는 **왼쪽 위 0번, 오른쪽 진행 후 다음 행**, 오른쪽 아래 15번입니다. Unity UV 원점 차이에 따른 행 순서는 첫 프레임으로 확인합니다.
3. 60fps 기준 16프레임의 길이는 16/60초입니다. 기존 공격 동작과 재생 타이밍을 유지합니다. 15번은 빈 프레임이며 임의의 반복 재생을 넣지 않습니다.
4. 흰색 RGB + straight alpha 강도입니다. 가산 `SrcAlpha One`에서 alpha를 한 번만 곱합니다. 셰이더 내부에서 이미 alpha를 곱했다면 이중 곱이 생기지 않도록 기존 계약을 확인합니다. 색상은 재질 tint로 부여합니다.
5. 제안 임포트 값: Max Size 1024, sRGB ON(흰색 RGB), Alpha Source Input, Alpha Is Transparency ON, Wrap Clamp, Filter Bilinear, Mipmaps ON, 모바일 ASTC 6×6. 프로젝트의 기존 설정과 맞춘 뒤 적용합니다. 이 패키지에서는 .meta를 생성하지 않았습니다.
6. 최대 알파 201은 그대로입니다. 요청서의 약 1.27 재질 배율 보정은 Unity 담당자가 실제 화면에서 판단합니다. 텍스처에 배율을 굽지 않았습니다.
7. 128/176/256px, Gamma/Linear, 밝고 어두운 바닥, 실제 mip 수준 및 모바일 압축에서 다시 확인합니다. Unity의 투명 RGB 확장·밉맵 생성 때문에 이 직접 ASTC 테스트와 달라질 수 있습니다. 밉맵 포함 최종 메모리와 셀 번짐은 여기서 검증하지 않았습니다.
8. 사용자 승인 전에는 Unity 반영/커밋/기존 에셋 교체를 진행하지 않습니다.

## 재현 및 파일 구분

제작 수식은 BuildV3.py, 기존 검수 자료 생성은 ReviewV3.py, 마지막 두 항목의 판정과 압축 비교는 FinalReview.py입니다. FinalReview.py는 이미 존재하는 PNG/ASTC 복원본을 읽으며 그림을 다시 만들지 않습니다. 이미 검증된 PNG를 쓸 때 재생성할 필요가 없습니다. Python 3.10+, numpy, Pillow(기본 폰트 size 지원 버전), scipy가 필요하며 영상 생성에는 ffmpeg/ffprobe가 필요합니다.

검사: `python review/Vfx/BladeImpactPilotV3/check_impact_flipbook.py assets/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png`

미리보기 재생성: `python source/Vfx/BladeImpactPilotV3/ReviewV3.py review/Vfx/BladeImpactPilotV3/Reference/V2_Impact_Blade_4x4.png review/Vfx/BladeImpactPilotV3/Reference/V2_Motion.json`

위 명령은 gpt-handoff 디렉터리에서 실행합니다. Reference는 원본 복사본이며 v2를 새로 생성한 것이 아닙니다. ReviewV3.py 재실행 시 시각 검수 상태는 미검수로 되돌아갑니다. ASTC 인코더는 패키지에 넣지 않았으며 명령/버전은 Astc6x6/CompressionCommands.txt에 기록했습니다. SHA256SUMS.txt는 패키지 파일 무결성 확인용입니다.

최종 두 항목만 재검증: `python source/Vfx/BladeImpactPilotV3/FinalReview.py`. 실행 후 시각 검수 상태를 다시 확인해야 합니다. BeforeFinalCheck는 비교용 이전 파일 보관본이며 런타임으로 가져오지 않습니다.
