"""Native 4x vector redraw requested by Claude N1/N2/N3. No V1/V2 pixel reuse.
Python 3.10+, Pillow, numpy, scipy. Motion.json is unchanged from approved V2.
"""
from pathlib import Path
import json, math, hashlib, subprocess, sys
import numpy as np
from PIL import Image, ImageDraw
from scipy.ndimage import distance_transform_edt

HERE=Path(__file__).resolve().parent
ROOT=HERE.parents[2]
OUT=ROOT/'assets/LuminaArt/Vfx/Impact';OUT.mkdir(parents=True,exist_ok=True)
REVIEW=ROOT/'review/Vfx/BladeImpactPilotV3';REVIEW.mkdir(parents=True,exist_ok=True)
M=json.loads((HERE/'Motion.json').read_text())
SS=4;N=256*SS;C=127.5
Y,X=np.mgrid[:N,:N].astype(np.float32)
X=(X+.5)/SS-.5;Y=(Y+.5)/SS-.5
TARGET=[100,78,58,43,31,23,16,11,7,4.7,3,1.8,.9,.38,.1,0]
LENGTHS=[11,9,12,10,12,9,13,11]
WIDTHS=[3,2.5,3.3,2.5,3.7,2.8,3.5,3]

def polygon(vertices):
    im=Image.new('L',(N,N))
    ImageDraw.Draw(im).polygon([((x+.5)*SS-.5,(y+.5)*SS-.5) for x,y in vertices],fill=255)
    return np.array(im,dtype=np.float32)/255

def placed(points,center,angle,scale=1):
    rad=math.radians(angle);u=np.array([math.cos(rad),math.sin(rad)]);v=np.array([-u[1],u[0]])
    return [np.array(center)+(u*x+v*y)*scale for x,y in points]

def compact_glow(body,radius=3,amplitude=.035):
    # Distance to the actual body, not a polygon crop. C1 smoothstep reaches 0.
    d=distance_transform_edt(body==0)/SS
    u=np.clip(1-d/radius,0,1)
    return amplitude*u*u*(3-2*u)*(body==0)

def core(scale):
    if scale<=0:return np.zeros((N,N),np.float32)
    length=147*scale;halfwidth=5.4*scale
    points=[(-length,0),(0,-halfwidth),(length,0),(0,halfwidth)]
    body=np.maximum(polygon(placed(points,[C,C],45)),polygon(placed(points,[C,C],-45)))
    # Symmetry is native vector symmetry, no reflected bitmap seam.
    d=9*scale
    body=np.maximum(body,polygon([(C,C-d),(C+d,C),(C,C+d),(C-d,C)]))
    r2=(X-C)**2+(Y-C)**2
    radial=.038*np.exp(-r2/(2*(32*scale)**2))+.035*np.exp(-r2/(2*(8*scale)**2))
    return body+compact_glow(body,2.2,.022)+radial

def shard(j,pose):
    length=LENGTHS[j];w=WIDTHS[j]
    # Newly drawn pointed metal kite, clean outer silhouette and one internal facet.
    points=[(-length,-.45*w),(.28*length,-w),(length,0),(-.36*length,w)]
    body=polygon(placed(points,pose['center'],pose['angle_deg'],pose['scale']))
    facet=polygon(placed([points[0],points[2],points[3]],pose['center'],pose['angle_deg'],pose['scale']))
    return body*.75+facet*.18+compact_glow(body,3,.028)

def down(a):
    # Exact 4x area average, avoids sharpening halos and ringing.
    return a.reshape(256,SS,256,SS).mean(axis=(1,3))

def rgba(a):
    a=np.clip(np.rint(a*255),0,255).astype(np.uint8)
    out=np.zeros((*a.shape,4),np.uint8);out[:,:,:3]=255;out[:,:,3]=a # White RGB padding, alpha unchanged
    return Image.fromarray(out,'RGBA')

raw=[];raw_core=[];raw_parts=[];core_centers=[];master0=None
for i in range(16):
    if i==15:
        raw.append(np.zeros((256,256)));raw_core.append(np.zeros((256,256)));raw_parts.append(np.zeros((256,256)));core_centers.append(None);continue
    cp=core(M['core_scales'][i])*M['core_gains'][i]
    cp_small=down(cp)
    if i<8:
        yy,xx=np.nonzero(cp_small>=cp_small.max()*.9)
        core_centers.append([float(xx.mean()),float(yy.mean())])
    else:core_centers.append(None)
    pp=np.zeros((N,N),np.float32)
    for j,pose in enumerate(M['particles'][i]):
        sp=shard(j,pose)
        if i==0:rgba(sp).save(HERE/f'Shard{j:02}Master4x.png',optimize=True)
        pp+=sp
    if i==0:rgba(cp/.8).save(HERE/'SlashGlowMaster4x.png',optimize=True)
    e=cp+pp*M['particle_gains'][i]
    if i==0:master0=e.copy()
    raw.append(down(e))
    raw_core.append(cp_small);raw_parts.append(down(pp))

# Keep V2 frame0 max alpha 201. New shape areas need intensity-only normalization
# to preserve the exact approved integrated energy ratios; motion is untouched.
base_gain=(201/255)/raw[0].max()
e0=raw[0].sum()*base_gain
frames=[];corrections=[];metrics=[]
initial_gain=[e0*TARGET[i]/100/raw[i].sum() if i<15 else 0 for i in range(16)]
effective_parts=[M['particle_gains'][i]*initial_gain[i] for i in range(16)]
for i in range(14,-1,-1):effective_parts[i]=max(effective_parts[i],effective_parts[i+1])
effective_core=[]
for i,r in enumerate(raw):
    gain=initial_gain[i]
    pp=raw_parts[i]*effective_parts[i]
    remaining=e0*TARGET[i]/100-pp.sum()
    cg=remaining/raw_core[i].sum() if i<8 else 0
    assert cg>=0
    effective_core.append(float(cg))
    e=raw_core[i]*cg+pp
    assert e.max()<=1,(i,e.max())
    e[:8]=0;e[-8:]=0;e[:,:8]=0;e[:,-8:]=0
    f=rgba(e);frames.append(f);corrections.append(float(gain))
    a=np.array(f)[:,:,3].astype(float)
    yy,xx=np.nonzero(a>8)
    gy,gx=np.gradient(a)
    mask=a>=.9*a.max() if a.max() else np.zeros_like(a,bool)
    my,mx=np.nonzero(mask)
    metrics.append({'frame':i,'energy':float(a.sum()/255),'content_size':[int(xx.max()-xx.min()+1),int(yy.max()-yy.min()+1)] if len(xx) else [0,0],
      'alpha_max':int(a.max()),'sharpness':float(np.hypot(gx,gy)[a>12.75].mean()) if np.any(a>12.75) else None,
      'peak_center_error':float(max(abs(mx.mean()-C),abs(my.mean()-C))) if len(mx) else None,'slash_center':core_centers[i],
      'slash_center_error':max(abs(v-C) for v in core_centers[i]) if core_centers[i] else None})
for row in metrics:row['brightness_pct']=row['energy']/metrics[0]['energy']*100
atlas=Image.new('RGBA',(1024,1024))
for i,f in enumerate(frames):atlas.paste(f,((i%4)*256,(i//4)*256))
p=OUT/'Impact_Blade_4x4.png';atlas.save(p,optimize=True)
rgba(master0*corrections[0]).save(HERE/'Frame0Master4x.png',optimize=True)
(HERE/'ArtworkParameters.json').write_text(json.dumps({'supersampling':SS,'cell_origin':[C,C],'slash_length':147,'slash_halfwidth':5.4,'shard_lengths':LENGTHS,'shard_widths':WIDTHS,'glow_radius_shards_px':3,'target_brightness_pct':TARGET,'intensity_corrections':corrections,'core_intensity_corrections':effective_core,'effective_particle_gains':effective_parts,'motion_change':False},indent=2))
res=subprocess.run([sys.executable,str(REVIEW/'check_impact_flipbook.py'),str(p)],capture_output=True,text=True)
(REVIEW/'CheckResults.txt').write_text(res.stdout+res.stderr)
v={'frames':metrics,'target_brightness_pct':TARGET,'corrections':corrections,'asset_sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'motion_sha256':hashlib.sha256((HERE/'Motion.json').read_bytes()).hexdigest(),'checker_exit_code':res.returncode,'unity_tested':False,'core_center_max_error':max(r['slash_center_error'] or 0 for r in metrics),'effective_particle_gains':effective_parts}
(REVIEW/'Validation.json').write_text(json.dumps(v,indent=2))
print(res.stdout);print('additional',v['core_center_max_error'],v['effective_particle_gains'])
sys.exit(res.returncode)
