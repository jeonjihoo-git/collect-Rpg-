"""Focused final review. Reads existing textures; never rebuilds artwork or changes Motion.
Run from any directory. Requires numpy, Pillow, scipy, ffmpeg/ffprobe.
"""
from pathlib import Path
import numpy as np,json,hashlib,subprocess,math,csv
from PIL import Image,ImageDraw,ImageFont
from scipy.ndimage import map_coordinates
S=Path(__file__).resolve().parent;ROOT=S.parents[2];R=ROOT/'review/Vfx/BladeImpactPilotV3';F=R/'FinalCheck';F.mkdir(exist_ok=True);A=R/'Astc6x6';B=R/'BeforeFinalCheck'
P=ROOT/'assets/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png'
def lin(a):return np.where(a<=.04045,a/12.92,((a+.055)/1.055)**2.4)
def srgb(a):return np.where(a<=.0031308,12.92*a,1.055*np.maximum(a,0)**(1/2.4)-.055)
def read(p):return np.asarray(Image.open(p).convert('RGBA')).astype(float)/255
def cell(a,i):return a[i//4*256:(i//4+1)*256,i%4*256:(i%4+1)*256]
def comp(a,size=256,bg=(56,66,79),linear=True,power=1):
    rgb=lin(a[:,:,:3]) if linear else a[:,:,:3]
    xy=(np.arange(size)+.5)*256/size-.5;y,x=np.meshgrid(xy,xy,indexing='ij')
    al=map_coordinates(a[:,:,3]**power,[y,x],order=1,mode='nearest')
    col=np.stack([map_coordinates(rgb[:,:,k],[y,x],order=1,mode='nearest') for k in range(3)],axis=2)
    bg=np.asarray(bg)/255
    out=srgb(lin(bg)+col*al[:,:,None]) if linear else bg+col*al[:,:,None]
    return np.clip(out,0,1)
def img(a):return Image.fromarray(np.uint8(np.rint(np.clip(a,0,1)*255)))
font=ImageFont.load_default(size=18);small=ImageFont.load_default(size=14)
a=read(P);oldsrc=read(B/'Source.png');old=read(B/'Decoded.png');dec=read(A/'Decoded.png')
# Validity is independent of visual judgement.
assert np.array_equal(a[:,:,3],oldsrc[:,:,3])
assert np.array_equal(a[oldsrc[:,:,3]>0],oldsrc[oldsrc[:,:,3]>0])
assert (S/'Motion.json').read_bytes()==(R/'Reference/V2_Motion.json').read_bytes()
assert (R/'CheckResults.txt').read_text().count('PASS')==15
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
base={};frames=[]
for label,z in [('before',old),('final',dec)]:
 err=a[:,:,3]-z[:,:,3]
 base[label]={'alpha_psnr_db':float(-10*np.log10(np.mean(err**2))),'alpha_max_abs_error_255':float(abs(err).max()*255)}
for i in range(16):
 c=cell(dec,i);o=cell(a,i);al=c[:,:,3]
 eo=float((o[:,:,0]*o[:,:,3]).sum());ed=float((c[:,:,0]*c[:,:,3]).sum())
 border=max(al[:8].max(),al[-8:].max(),al[:,:8].max(),al[:,-8:].max())
 frames.append({'frame':i,'source_energy':eo,'decoded_energy':ed,'energy_retention_pct':ed/eo*100 if eo else None,'edge8_alpha_max_255':int(round(border*255)),'alpha_max_255':int(round(al.max()*255))})
assert max(x['edge8_alpha_max_255'] for x in frames)==0
assert frames[15]['alpha_max_255']==0
(A/'CompressionResults.json').write_text(json.dumps({'encoder':'Arm astcenc 5.7.1 SSE2','profile':'LDR sRGB','block':'6x6','preset':'exhaustive','input_sha256':sha(P),'compressed_bytes':(A/'Impact_Blade_4x4.astc').stat().st_size,**base['final'],'unity_import_tested':False,'gpu_tested':False,'frames':frames},indent=2))
metrics=[]
for size in [128,176,256]:
 for linear in [False,True]:
  for bg in [(56,66,79),(163,167,173)]:
   for i in range(16):
    ref=comp(cell(a,i),size,bg,linear)
    for label,z in [('before',old),('final',dec)]:
     # Same white-padded reference for both to compare full final sampling contract.
     c=comp(cell(z,i),size,bg,linear);e=abs(c-ref)*255;mx=e.max(axis=2)
     metrics.append({'size':size,'space':'Linear' if linear else 'Gamma','background':'dark' if bg[0]==56 else 'light','frame':i,'variant':label,'max_channel_error_255':float(mx.max()),'rms_channel_error_255':float(np.sqrt((e**2).mean())),'pixels_error_over_3':int((mx>3).sum()),'pixels_error_over_10':int((mx>10).sum())})
(F/'ScreenMetrics.json').write_text(json.dumps(metrics,indent=2))
with (F/'ScreenMetrics.csv').open('w',newline='') as f:
 w=csv.DictWriter(f,fieldnames=list(metrics[0]));w.writeheader();w.writerows(metrics)
for linear in [False,True]:
 for bg in [(56,66,79),(163,167,173)]:
  c=Image.new('RGB',(960,950),'#121A2C');d=ImageDraw.Draw(c)
  for row,(label,z) in enumerate([('SOURCE PNG',a),('BEFORE ASTC',old),('FINAL ASTC',dec)]):
   for col,size in enumerate([128,176,256]):
    x=col*320;y=row*315;d.text((x+12,y+10),f'{label} / {size}px / frame 0',font=font,fill='white')
    c.paste(img(comp(cell(z,0),size,bg,linear)),(x+(320-size)//2,y+38))
  c.save(F/('ActualSize'+('Linear' if linear else 'Gamma')+('Dark' if bg[0]==56 else 'Light')+'.png'))
# Exact enlarged crops; nearest keeps compression errors visible, no smoothing.
c=Image.new('RGB',(1120,640),'#121A2C');d=ImageDraw.Draw(c)
for row,(i,box) in enumerate([(0,(24,24,72,72)),(6,(78,78,126,126))]):
 for col,(label,z) in enumerate([('SOURCE',a),('BEFORE ASTC',old),('FINAL ASTC',dec),('FINAL ABS DIFF x4',None)]):
  x=col*280;y=row*320
  ca=comp(cell(a,i));cb=comp(cell(dec,i))
  arr=abs(ca-cb)*4 if z is None else comp(cell(z,i))
  c.paste(img(arr).crop(box).resize((240,240),Image.Resampling.NEAREST),(x+12,y+40))
  d.text((x+12,y+10),f'F{i} / {label}',font=small,fill='white')
c.save(F/'FinalTipZoomComparison.png');c.save(A/'CompressionComparison.png')
# Alpha-band evidence, no perceptual enhancement on the first two panels.
c=Image.new('RGB',(1088,622),'#121A2C');d=ImageDraw.Draw(c)
for j,(label,linear,power) in enumerate([('Gamma / normal',False,1),('Linear / normal',True,1),('Linear / alpha^0.5',True,.5),('Stored alpha x16',False,1)]):
 x=16+j*268
 q=img(np.repeat(cell(a,0)[:,:,3,None],3,axis=2)*16) if j==3 else img(comp(cell(a,0),linear=linear,power=power))
 c.paste(q,(x,44));d.text((x,16),label,font=small,fill='white')
 c.paste(q.crop((96,96,160,160)).resize((256,256),Image.Resampling.NEAREST),(x,334))
 d.text((x,308),'Center crop / 4x nearest',font=small,fill='#C9A55C')
c.save(F/'AlphaBandDiagnosis.png')
# All frames at 1:1 final source and final ASTC on dark linear background.
c=Image.new('RGB',(2144,1200),'#121A2C');d=ImageDraw.Draw(c)
for i in range(16):
 x=(i%4)*536;y=(i//4)*300
 for j,z in enumerate([a,dec]):c.paste(img(comp(cell(z,i))),(x+j*264,y+30))
 d.text((x,y+4),f'Frame {i:02} / source | final ASTC',font=font,fill='white')
c.save(F/'AllFramesSourceAstc.png')
# Visible diagonal extent at actual display sizes, contrast threshold stated.
extents=[]
for size in [128,176,256]:
 for i in [0,2,6]:
  for label,z in [('source',a),('before',old),('final',dec)]:
   out=comp(cell(z,i),size);bg=np.array([56,66,79])/255
   vis=(out-bg).max(axis=2)*255>10
   yy,xx=np.mgrid[:size,:size];roi=(abs(xx-yy)<=2)&(xx<size//2)&(yy<size//2)
   coords=np.argwhere(vis&roi)
   extents.append({'size':size,'frame':i,'variant':label,'tip_min_xy':int(coords.min()) if len(coords) else None,'criterion':'top-left arm within 2px diagonal, display contrast >10/255'})
(F/'TipExtents.json').write_text(json.dumps(extents,indent=2))
# Quantization exists in the PNG. Color-space and diagnostic exponent amplify it.
bg=np.array([56,66,79])/255;steps=[]
for n in range(9):
 steps.append({'alpha_step':[n,n+1],'gamma_step_255':1.,'linear_step_255':float(np.max(srgb(lin(bg)+(n+1)/255)-srgb(lin(bg)+n/255))*255),'diagnostic_sqrt_linear_step_255':float(np.max(srgb(lin(bg)+np.sqrt((n+1)/255))-srgb(lin(bg)+np.sqrt(n/255)))*255)})
radials={}
for name,(dx,dy) in {'east':(1,0),'west':(-1,0),'south':(0,1),'north':(0,-1)}.items():
 radials[name]=[int(round(cell(a,0)[round(127.5+dy*r),round(127.5+dx*r),3]*255)) for r in range(55)]
(F/'AlphaBandEvidence.json').write_text(json.dumps({'classification':'Stored 8-bit alpha quantization, amplified by linear compositing and alpha^0.5; not a circular mask cutoff.','radii_px':list(range(55)),'alpha_radials_255':radials,'steps_on_dark_bg':steps,'alpha_changed':False},indent=2))
# New compression A/B video only. Original source Gamma/Linear videos are reused.
def vidframe(i):
 c=Image.new('RGB',(960,680),'#121A2C');d=ImageDraw.Draw(c)
 d.text((16,12),'V3 FINAL CHECK / 60FPS / OFFLINE BASE-LEVEL SAMPLING',font=font,fill='white')
 for row,linear in enumerate([False,True]):
  for col,(label,z) in enumerate([('PNG',a),('BEFORE ASTC',old),('FINAL ASTC',dec)]):
   x=col*320+32;y=76+row*306
   d.text((x,y-24),('Linear' if linear else 'Gamma')+' / '+label,font=small,fill='white')
   c.paste(img(comp(cell(z,i),linear=linear)) if i<16 else Image.new('RGB',(256,256),(56,66,79)),(x,y))
 return c
vp=F/'FinalCompressionCompare60fps.mp4'
proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x680','-r','60','-i','-','-an','-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(vp)],stdin=subprocess.PIPE)
for _ in range(4):
 for i in range(16):proc.stdin.write(vidframe(i).tobytes())
 for _ in range(44):proc.stdin.write(vidframe(16).tobytes())
proc.stdin.close();assert proc.wait()==0
probe=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,avg_frame_rate,nb_frames,duration','-of','json',str(vp)]))['streams'][0]
r=subprocess.run(['ffmpeg','-v','error','-i',str(vp),'-f','null','-'],capture_output=True,text=True);assert r.returncode==0 and not r.stderr
receipt={'source_sha256':sha(P),'previous_source_sha256':sha(B/'Source.png'),'motion_sha256':sha(S/'Motion.json'),'motion_identical_to_v2':True,'alpha_byte_identical_to_previous_v3':True,'visible_rgba_identical_to_previous_v3':True,'all_15_checker_pass':True,'compression':base,'video':{**probe,'decode_ok':True},'visual_inspection_pending':True,'unity_executed':False,'gpu_executed':False,'mipmaps_tested':False,'approval':'pending'}
(F/'FinalCheckResults.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({'compression':base,'retention':[min(x['energy_retention_pct'] for x in frames[:15]),max(x['energy_retention_pct'] for x in frames[:15])],'tip_extents_f0':[x for x in extents if x['frame']==0]},indent=2))
