"""Review already-built files; does not rebuild artwork or access Unity.
Usage: python ReviewV3.py <V2 production PNG> <V2 Motion.json>
Requires Pillow, numpy, ffmpeg, ffprobe. Decode ASTC before running.
"""
from pathlib import Path
import sys,json,hashlib,subprocess,csv,math
import numpy as np
from PIL import Image,ImageDraw,ImageFont

HERE=Path(__file__).resolve().parent;ROOT=HERE.parents[2]
R=ROOT/'review/Vfx/BladeImpactPilotV3';A=R/'Astc6x6'
P=ROOT/'assets/LuminaArt/Vfx/Impact/Impact_Blade_4x4.png'
old=Image.open(sys.argv[1]).convert('RGBA');new=Image.open(P).convert('RGBA');decoded=Image.open(A/'Decoded.png').convert('RGBA')
v=json.loads((R/'Validation.json').read_text());motion=json.loads((HERE/'Motion.json').read_text())
font=ImageFont.load_default(size=20);small=ImageFont.load_default(size=15)
def cell(im,i):
    x=i%4*256;y=i//4*256;return im.crop((x,y,x+256,y+256))
def srgb_to_linear(x):return np.where(x<=.04045,x/12.92,((x+.055)/1.055)**2.4)
def linear_to_srgb(x):
    x=np.maximum(x,0)
    return np.where(x<=.0031308,12.92*x,1.055*x**(1/2.4)-.055)
def composite(im,bg,mode='Linear',size=256,power=1,tint=(255,255,255)):
    # Resample alpha directly (RGB is white on visible texels). No sharpening filter.
    a=np.array(im.getchannel('A').resize((size,size),Image.Resampling.BOX),dtype=float)/255
    # White-RGB reference formula; ASTC preview compares alpha coverage.
    # Compression energy metrics below separately include actual decoded RGB.
    b=np.array(bg,dtype=float)/255;t=np.array(tint,dtype=float)/255
    a=a**power
    if mode=='Linear':out=linear_to_srgb(srgb_to_linear(b)+srgb_to_linear(t)*a[:,:,None])
    else:out=b+t*a[:,:,None]
    return Image.fromarray(np.rint(np.clip(out,0,1)*255).astype(np.uint8))

dark=(56,66,79);light=(163,167,173)
def preview(i,mode='Linear',slow=False):
    canvas=Image.new('RGB',(960,768),'#121A2C');d=ImageDraw.Draw(canvas)
    d.text((20,14),f'LUMINA / BLADE IMPACT V3 / {mode.upper()} ADDITIVE',font=font,fill='white')
    d.text((20,45),('4x slower review; encoded at 60fps' if slow else '60fps / 16 atlas frames = 0.267s')+' / Offline simulation, no bloom',font=small,fill='#A3A7AD')
    for row,bg in enumerate([dark,light]):
        y=88+row*332
        for col,size in enumerate([128,176,256]):
            x=20+col*310;d.rectangle((x,y,x+287,y+287),fill=bg)
            if i<16:canvas.paste(composite(cell(new,i),bg,mode,size),(x+(288-size)//2,y+(288-size)//2))
            d.text((x,y+294),f'{size}px / '+('DARK #38424F' if row==0 else 'LIGHT #A3A7AD'),font=small,fill='white')
    return canvas

for mode in ['Gamma','Linear']:
    preview(0,mode).save(R/f'FirstFrame{mode}.png')
    for slow in ([False,True] if mode=='Linear' else [False]):
        name=f'Playback{mode}'+('Slow' if slow else '')+'60fps.mp4'
        proc=subprocess.Popen(['ffmpeg','-v','error','-y','-f','rawvideo','-pix_fmt','rgb24','-s','960x768','-r','60','-i','-','-an','-c:v','libx264','-preset','medium','-crf','16','-pix_fmt','yuv420p','-movflags','+faststart',str(R/name)],stdin=subprocess.PIPE)
        for rep in range(4):
            for i in range(16):
                buf=preview(i,mode,slow).tobytes()
                for _ in range(4 if slow else 1):proc.stdin.write(buf)
            buf=preview(16,mode,slow).tobytes()
            for _ in range(44):proc.stdin.write(buf)
        proc.stdin.close();assert proc.wait()==0

zoom=Image.new('RGB',(2128,1168),'#121A2C');d=ImageDraw.Draw(zoom)
for row,(label,im) in enumerate([('V2',old),('V3',new)]):
    y=36+row*576
    d.text((16,y-26),f'{label} / LINEAR ADDITIVE / alpha ^ 0.5 / exact 2x nearest zoom',font=font,fill='#C9A55C')
    for col,i in enumerate([0,2,5,8]):
        x=16+col*528
        q=composite(cell(im,i),dark,'Linear',256,.5).resize((512,512),Image.Resampling.NEAREST)
        zoom.paste(q,(x,y));d.text((x,y+520),f'Frame {i:02}',font=small,fill='white')
zoom.save(R/'DefectZoomComparison.png')

contact=Image.new('RGB',(1088,1256),'#121A2C');d=ImageDraw.Draw(contact)
d.text((16,12),'V3 / LINEAR ADDITIVE / ALL 16 FRAMES',font=font,fill='white')
for i in range(16):
    x=16+(i%4)*268;y=48+(i//4)*300
    contact.paste(composite(cell(new,i),dark),(x,y))
    d.text((x,y+264),f'{i:02} / {v["frames"][i]["brightness_pct"]:.2f}%',font=small,fill='white')
contact.save(R/'FrameContactSheetLinear.png')

detail=Image.new('RGB',(1040,764),'#121A2C');d=ImageDraw.Draw(detail)
for row,(label,im) in enumerate([('V2',old),('V3',new)]):
    y=40+row*374
    for col,(title,box) in enumerate([('N1 / shard edge',(160,88,240,168)),('N2 / central fade',(64,64,192,192)),('N3 / diagonal slash',(40,40,200,200))]):
        x=16+col*342
        q=composite(cell(im,0),dark,'Linear',256,.5 if col<2 else 1).crop(box).resize((320,320),Image.Resampling.NEAREST)
        detail.paste(q,(x,y));d.text((x,y-26),f'{label} / {title}',font=small,fill='#C9A55C')
detail.save(R/'DefectDetailComparison.png')

orig=np.array(new,dtype=float)/255;dec=np.array(decoded,dtype=float)/255
err=orig[:,:,3]-dec[:,:,3];mse=float(np.mean(err**2))
astc={'encoder':'Arm astcenc 5.7.1 SSE2','profile':'LDR sRGB','block':'6x6','preset':'exhaustive','input_sha256':hashlib.sha256(P.read_bytes()).hexdigest(),
 'compressed_bytes':(A/'Impact_Blade_4x4.astc').stat().st_size,'alpha_psnr_db':float(-10*math.log10(mse)),'alpha_max_abs_error_255':float(abs(err).max()*255),
 'unity_import_tested':False,'gpu_tested':False,'frames':[]}
for i in range(16):
    o=np.array(cell(new,i),dtype=float)/255;c=np.array(cell(decoded,i),dtype=float)/255
    eo=float((o[:,:,0]*o[:,:,3]).sum());ec=float((c[:,:,0]*c[:,:,3]).sum());al=c[:,:,3]
    border=max(al[:8].max(),al[-8:].max(),al[:,:8].max(),al[:,-8:].max())
    astc['frames'].append({'frame':i,'source_energy':eo,'decoded_energy':ec,'energy_retention_pct':ec/eo*100 if eo>0 else None,'edge8_alpha_max_255':int(round(border*255)),'alpha_max_255':int(round(al.max()*255))})
(A/'CompressionResults.json').write_text(json.dumps(astc,indent=2))
cmp=Image.new('RGB',(1104,840),'#121A2C');d=ImageDraw.Draw(cmp)
for row,i in enumerate([0,6]):
    for col,(label,im) in enumerate([('Source PNG',new),('ASTC 6x6 decoded',decoded)]):
        x=16+col*544;y=42+row*400
        q=composite(cell(im,i),dark,'Linear').crop((40,40,216,216)).resize((352,352),Image.Resampling.NEAREST)
        cmp.paste(q,(x,y));d.text((x,y-26),f'Frame {i} / {label}',font=font,fill='white')
cmp.save(A/'CompressionComparison.png')

# Radial evidence between arms, not a generalized automated aesthetic verdict.
radial={}
for name,im in [('v2',old),('v3',new)]:
    a=np.array(cell(im,0))[:,:,3]
    radial[name]={}
    for direction,(dx,dy) in {'east':(1,0),'south':(0,1),'west':(-1,0),'north':(0,-1)}.items():
        radial[name][direction]=[int(a[round(127.5+r*dy),round(127.5+r*dx)]) for r in range(61)]
(R/'CentralRadialProfiles.json').write_text(json.dumps({'radii_px':list(range(61)),'alpha_values_255':radial},indent=2))
with (R/'FrameMetrics.csv').open('w',newline='') as f:
    w=csv.writer(f);w.writerow(['frame','remaining_brightness_pct','width_px','height_px','alpha_max','sharpness','slash_center_error_px'])
    for q in v['frames']:w.writerow([q['frame'],q['brightness_pct'],*q['content_size'],q['alpha_max'],q['sharpness'],q['slash_center_error']])
receipt={'motion_byte_identical_to_v2':(HERE/'Motion.json').read_bytes()==Path(sys.argv[2]).read_bytes(),'png_sha_matches_validation':hashlib.sha256(P.read_bytes()).hexdigest()==v['asset_sha256'],
 'effective_particle_opacity_nonincreasing':bool(np.all(np.diff(v['effective_particle_gains'])<=0)),
 'core_center_le_2_px':v['core_center_max_error']<=2,'videos':[],'visual_review_pending':True}
for path in sorted(R.glob('*.mp4')):
    info=json.loads(subprocess.check_output(['ffprobe','-v','error','-select_streams','v:0','-show_entries','stream=codec_name,width,height,avg_frame_rate,nb_frames,duration','-of','json',str(path)]))['streams'][0]
    result=subprocess.run(['ffmpeg','-v','error','-i',str(path),'-f','null','-'],capture_output=True,text=True)
    assert result.returncode==0 and not result.stderr
    receipt['videos'].append({'file':path.name,**info,'decode_ok':True})
(R/'DeliveryChecks.json').write_text(json.dumps(receipt,indent=2))
print(json.dumps({'astc_alpha_psnr_db':astc['alpha_psnr_db'],'astc_bytes':astc['compressed_bytes'],'max_decoded_gutter_alpha':max(r['edge8_alpha_max_255'] for r in astc['frames']),'motion_identical':receipt['motion_byte_identical_to_v2']},indent=2))
